
        function func(id){
            id.innerHTML="onclick hello changed";
        }
        document.write(new Date());
        console.log("Hello Node.js");   
