<?php
$server="localhost";
$username="root";
$password="";
$databse="tripdb";

$con=mysqli_connect($server,$username,$password,$databse);
$mysqli=mysqli_connect($server,$username,$password,$databse);

?>