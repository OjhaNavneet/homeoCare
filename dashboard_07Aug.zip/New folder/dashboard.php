<?php
include('connection.php');
$result=mysqli_query($mysqli,"SELECT * from trip ORDER by id ASC");
$x=mysqli_query($mysqli,"SELECT * from trip ORDER by id desc LIMIT 5");
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="temp.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
    <title>DashBoard</title>
</head>
<body>


    <div class="sidebarDashboard">
        
    </div>
    <div class="topbarDashboard">

    </div>

    
    <div class="mainContent">
        <div class="jumb  otron jumbotron-fluid">
            <h2>Dashboard</h2>
        </div>
        <div class="container">
            <div class="row ">
                <div class="col-3 dataBox">
                        <div class="row">
                            <div class="col-8">
                               Appointments Today
                               <br>
                               7
                            </div>
                            <div class="col-4">
                               Pic
                            </div>
                        </div>
                </div>
                <div class="col-3 dataBox">
                    <div class="row">
                        <div class="col-8">
                           Appointments Today
                           <br>
                           7
                        </div>
                        <div class="col-4">
                           Pic
                        </div>
                    </div>
            </div>
            <div class="col-3 dataBox">
                <div class="row">
                    <div class="col-8">
                       Appointments Today
                       <br>
                       7
                    </div>
                    <div class="col-4">
                       Pic
                    </div>
                </div>
        </div>
        <div class="col-3 dataBox">
            <div class="row">
                <div class="col-8">
                   Appointments Today
                   <br>
                   <?php
                   $query_run=mysqli_query($con,"SELECT id from trip ORDER by id");
                   $row=mysqli_num_rows($query_run);
                   echo $row;
                   ?>
                </div>
                <div class="col-4">
                   Pic
                </div>
            </div>
    </div>
                
               
            </div>
        </div>
        <br>
        <br>
        

        <div class="container">
            <div class="row">
                <div class="col-6">
                    <h4 class="text-center">Appointment</h4>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">Sr.No</th>
                            <th scope="col">First</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Appointment</th>
                            <th scope="col">Contact</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                          while($res=mysqli_fetch_array($result)){
                            echo '<tr>';
                            echo '<th>'.$res['id'].'</th>';
                            echo '<td>'.$res['name'].'</td>';
                            echo '<td>'.$res['roll'].'</td>';
                            echo '<td>'.$res['college'].'</td>';
                            echo '<td>'.$res['age'].'</td>';
                            echo '</tr>';
                            

                          }
                          ?>
                         
                      
                        </tbody>
                      </table>
                </div>
                <div class="col-6">
                    <h4 class="text-center">Appointment</h4>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">Sr.No</th>
                            <th scope="col">Name</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Appointment Date</th>
                            <th scope="col">Contact</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                          while($re=mysqli_fetch_array($x)){
                            echo '<tr>';
                            echo '<th>'.$re['id'].'</th>';
                            echo '<td>'.$re['name'].'</td>';
                            echo '<td>'.$re['roll'].'</td>';
                            echo '<td>'.$re['college'].'</td>';
                            echo '<td>'.$re['age'].'</td>';
                            echo '</tr>';
                            

                          }
                          ?>
                      
                        </tbody>
                      </table>
                </div>
            </div>
        </div>

        <p class="font-weight-light text-center">Designed by Chidiya Ghar</p>
    </div>
    <?php
    while($res=mysqli_fetch_array($result))
    {
      echo '<tr>';
      echo '<td>'.$res['name']. '</td>';
      echo '</tr>'; 
    }
    ?>
    
</body>
</html>