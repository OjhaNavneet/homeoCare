<?php
    $insert = false;
    if(isset($_POST['name'])){
    $server="localhost";
    $username="root";
    $password="";

    $conn=mysqli_connect($server,$username,$password);

    if($conn){
        echo "<br> true <br>";
    }
    else{
        echo "<br> false <br>";
    } 
    $name=$_POST['name'];
    $roll=$_POST['roll'];
    $college=$_POST['college'];
    $gender=$_POST['gender'];
    $age=$_POST['age'];
    $other=$_POST['other'];
    $sql="INSERT INTO `tripdb`.`trip` (`name`, `roll`, `college`, `gender`, `age`, `other`, `dt`) VALUES
     ('$name', '$roll', '$college', '$gender', '$age', '$other', current_timestamp())";

    // echo $sql;

        if($conn->query($sql)==true){
            echo "succesfully";
            $insert=true;
        }
        else{
            echo "error :$sql <br> $conn->error";
        }
        
    $conn->close();

    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php </title>
</head>
<body>
    <div class="container">
        Hello Sir
        <?php
        if($insert){
        echo "we are using php now";
}   
        
        ?>
        
    </div>
    <form action="index.php" method="post">
        <input type="name" name="fname" placeholder="Enter Your name">
        <input type="name" name="lname" placeholder="Enter Your name">
        <input type="name" name="age" placeholder="Enter Your name">
        <input type="name" name="contact" placeholder="Enter Your name">
        <input type="number" name="city" placeholder="Enter Your name">
        <input type="name" name="email" placeholder="Enter Your name">
        <input type="name" name="" placeholder="Enter Your name">
        
        <button type="submit">Submit</button> 
        
    </form>

    <?php
    echo $name;
    ?>

</body>
</html>